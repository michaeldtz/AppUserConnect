//
//  AppUserConnect
//
//  Created by Dietz, Michael on 4/4/11.
//  Copyright 2011 Michael Dietz
//


#import <Foundation/Foundation.h>
#import <CFNetwork/CFHTTPStream.h>

@protocol QNotifyBasicConnectionDelegate

-(void)     dataLoadingSuccessful:(NSData*)resultData:(BOOL)parsed;
-(void)     dataLoadingError:(NSString*) errorText;

@end

@interface APCConnection : NSObject {


	NSMutableData* receivedData; 

	id<QNotifyBasicConnectionDelegate> delegate; 
	int counter;
	
	NSString* contentType;
	
	NSString* username;
	NSString* password;
	
	NSString* urlTemp;
	
}

@property(assign)NSString* contentType;

-(void)   callURLAsyncPost:(NSString*)url:(NSString*)postdata:(id<QNotifyBasicConnectionDelegate>)_delegate;

@end
