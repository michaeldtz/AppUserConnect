//
//  AppUserConnect
//
//  Created by Dietz, Michael on 4/4/11.
//  Copyright 2011 Michael Dietz
//

#import "AppUserConnect.h"

//#define APPCONNECT_URL @"http://appuserconnect.appspot.com/appconnect"
#define APPCONNECT_URL @"http://localhost:8888/appconnect"

@implementation AppUserConnect

static NSMutableDictionary* actionDelegates; 
static NSString* keptQnid;

-(void)executeQNotify:(NSString*)qnid:(NSString*)position{
	
	NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
	NSString* clientID           = [userDefaults objectForKey:@"qnclientid"];
	
	NSDictionary* bundleInfo     = [[NSBundle mainBundle] infoDictionary];
	NSString* appID              = [bundleInfo objectForKey:@"CFBundleIdentifier"];
	NSString* appName            = [bundleInfo objectForKey:@"CFBundleName"];
	NSString* appVers            = [bundleInfo objectForKey:@"CFBundleVersion"];
	NSString* locale             = [[NSLocale currentLocale] localeIdentifier];
	
	if(clientID == nil || [clientID isEqualToString:@""]){
		clientID = [AppUserConnect generateUUID];
		[userDefaults setObject:clientID forKey:@"qnclientid"];
		[userDefaults synchronize];
	}
	
	NSMutableDictionary* jsonDic = [[NSMutableDictionary alloc] initWithCapacity:5];
	[jsonDic setObject:qnid         forKey:@"qnid"];
	[jsonDic setObject:clientID     forKey:@"clientid"];
	[jsonDic setObject:appID        forKey:@"appbundle"];
	[jsonDic setObject:appName      forKey:@"appname"];
	[jsonDic setObject:appVers      forKey:@"appversion"];
	[jsonDic setObject:locale       forKey:@"locale"];
	[jsonDic setObject:position     forKey:@"position"];
	
	APCConnection* connection = [[APCConnection alloc] init];
	NSMutableString* jsonString = [[NSMutableString alloc] initWithString:@"{"];
	
	int counter = 0;
	for(NSString* key in [jsonDic allKeys]){
		if(counter > 0)
			[jsonString appendFormat:@","];
		NSString* value = [jsonDic objectForKey:key];
		[jsonString appendFormat:@"\"%@\":\"%@\"", key,value];
		counter++;
	}
	[jsonString appendString:@"}"];
	
	[connection callURLAsyncPost:APPCONNECT_URL :jsonString :self];
}

#pragma mark Delegate

-(void)     dataLoadingSuccessful:(NSData*)resultData:(BOOL)parsed{
	NSString* dataString = [[NSString alloc] initWithData:resultData encoding:NSASCIIStringEncoding];
	NSMutableDictionary* jsonData = [[NSMutableDictionary alloc] init];
	
	//Prepare (Remove brackets at start and end)
	dataString = [dataString stringByReplacingOccurrencesOfString:@"{" withString:@""];
	dataString = [dataString stringByReplacingOccurrencesOfString:@"}" withString:@""];
	dataString = [dataString stringByReplacingOccurrencesOfString:@"\n" withString:@""];
	
	NSArray* pieces = [dataString componentsSeparatedByString:@","];
	for(NSString* piece in pieces){
		NSArray* keyAndValue = [piece componentsSeparatedByString:@":"];
		if([keyAndValue count] >= 2){
			
			NSString* key   = [keyAndValue objectAtIndex:0];
			key             = [key substringWithRange:NSMakeRange(1, [key length] - 2)];
			
			NSMutableString* value = [[NSMutableString alloc] init];
			for(int i = 1; i < [keyAndValue count]; i++){
				NSString* valuePart = [keyAndValue objectAtIndex:i];
				if(i > 1)
					[value appendString:@":"];
				[value appendString:valuePart];
			}
			
			NSRange range = NSMakeRange(1, [value length] - 2);
			NSString* valueStr = [value substringWithRange:range];
			[jsonData setObject:valueStr forKey:key];
		}
	}
	
	
	if(jsonData != nil && [[jsonData allKeys] count] != 0){
		
		NSString* title = [jsonData objectForKey:@"Title"];
		NSString* text  = [jsonData objectForKey:@"Text"];
		
		NSString* button1Text = [jsonData objectForKey:@"Button1Text"];
		NSString* button2Text = [jsonData objectForKey:@"Button2Text"];
		NSString* button3Text = [jsonData objectForKey:@"Button3Text"];
		
		button1Acti = [[jsonData objectForKey:@"Button1Action"] copy];	
		button2Acti = [[jsonData objectForKey:@"Button2Action"] copy];
		button3Acti = [[jsonData objectForKey:@"Button3Action"] copy];
		
		if(button3Text == nil || [button3Text isEqualToString:@""])
			button3Text = @"Cancel";
		
		UIAlertView* qnotifyView = [[UIAlertView alloc] initWithTitle:title message:text delegate:self cancelButtonTitle:button3Text otherButtonTitles:nil];
		
		if(button1Text != nil && ![button1Text isEqualToString:@""])
			[qnotifyView addButtonWithTitle:button1Text];
		
		if(button2Text != nil && ![button2Text isEqualToString:@""])
			[qnotifyView addButtonWithTitle:button2Text];
		
		[qnotifyView show];
	}
}

-(void)     dataLoadingError:(NSString*) errorText{
	NSLog(@"APC-Error: %@", errorText);
}

#pragma mark Action Handling

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
	
	[alertView dismissWithClickedButtonIndex:0 animated:YES];
	
	NSString* selectedAction = @"";
	if(buttonIndex == 0)
		selectedAction = button3Acti;
	else if(buttonIndex == 1)
		selectedAction = button1Acti;	
	else if(buttonIndex == 2)
		selectedAction = button2Acti;
	
	NSArray*  actionPieces = [selectedAction componentsSeparatedByString:@":"];
	NSString* actionName   = [actionPieces objectAtIndex:0];
	if([actionName isEqual:@"URL"]){
		if([actionPieces count]>=2){
			NSURL* url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"http://%@", [actionPieces objectAtIndex:1]]];
			if([[UIApplication sharedApplication] canOpenURL:url])
				[[UIApplication sharedApplication] openURL:url];
			else 
				NSLog(@"Action URL not valid: %@", selectedAction);
		}
	} else if([actionName isEqual:@"ITMS"]){
		if([actionPieces count]>=2){
			NSURL* url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"itms://%@", [actionPieces objectAtIndex:1]]];
			if([[UIApplication sharedApplication] canOpenURL:url])
				[[UIApplication sharedApplication] openURL:url];
			else 
				NSLog(@"Action ITMS not valid: %@", selectedAction);
		}
	} else if([actionName isEqual:@"ITMSAPPS"]){
		if([actionPieces count]>=2){
			NSURL* url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"itms-apps://%@", [actionPieces objectAtIndex:1]]];
			if([[UIApplication sharedApplication] canOpenURL:url])
				[[UIApplication sharedApplication] openURL:url];
			else 
				NSLog(@"Action ITMS-APPS not valid: %@", selectedAction);
		}
	} else if([actionName isEqual:@"APP"]){
		if([actionPieces count]>=2){
			NSURL* url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"http://itunes.com/apps/%@", [actionPieces objectAtIndex:1]]];
			if([[UIApplication sharedApplication] canOpenURL:url])
				[[UIApplication sharedApplication] openURL:url];
			else 
				NSLog(@"Action URL not valid: %@", selectedAction);
		}
	} else if([actionName isEqual:@"DEVELOPER"]){
		if([actionPieces count]>=2){
			NSURL* url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"http://itunes.com/%@", [actionPieces objectAtIndex:1]]];
			if([[UIApplication sharedApplication] canOpenURL:url])
				[[UIApplication sharedApplication] openURL:url];
			else 
				NSLog(@"Action URL not valid: %@", selectedAction);
		}
	} else if([actionName isEqual:@"DEVELOPAPP"]){
		if([actionPieces count]>=3){
			NSURL* url = [[NSURL alloc] initWithString:[NSString stringWithFormat:@"http://itunes.com/%@/%@", [actionPieces objectAtIndex:1], [actionPieces objectAtIndex:2]]];
			if([[UIApplication sharedApplication] canOpenURL:url])
				[[UIApplication sharedApplication] openURL:url];
			else 
				NSLog(@"Action URL not valid: %@", selectedAction);
		}
	} else if([actionName isEqual:@"EXIT"]){
		exit(0);	
	} else if([actionName isEqual:@"BADGE"]){
		int badgeNum = [[actionPieces objectAtIndex:1] intValue];
		[[UIApplication sharedApplication] setApplicationIconBadgeNumber:badgeNum];
	} else {
		if([[actionDelegates allKeys] containsObject:actionName]){
			id delegate = [actionDelegates objectForKey:actionName];
			if([delegate respondsToSelector:@selector(handleAction:::)]){
				[delegate handleAction:selectedAction:actionName:actionPieces];
			}
		}
	}
}

#pragma mark Helper Methods
+ (NSString *)generateUUID{
	CFUUIDRef   theUUID = CFUUIDCreate(NULL);
	CFStringRef string  = CFUUIDCreateString(NULL, theUUID);
	CFRelease(theUUID);
	return [(NSString *)string autorelease];
} 

+(void)setActionDelegate:(NSString*)action:(id)delegate{
	if(actionDelegates == nil)
		actionDelegates = [[NSMutableDictionary alloc] init];
	[actionDelegates setValue:delegate forKey:action];
}

#pragma mark External Access Method

+(void)executeAppUserConnect:(NSString*)qnid{
	[AppUserConnect executeAppUserConnect:qnid withPosition:@"DEFAULT"];
}

+(void)executeAppUserConnect:(NSString*)qnid withPosition:(NSString*)position{
	keptQnid = qnid;
	AppUserConnect* instance = [[AppUserConnect alloc] init];
	[instance executeQNotify:qnid:position];
}

+(void)executeAppUserConnectOnPosition:(NSString*)position{
	AppUserConnect* instance = [[AppUserConnect alloc] init];
	[instance executeQNotify:keptQnid:position];	
}


@end
