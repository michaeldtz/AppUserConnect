//
//  AppUserConnect
//
//  Created by Dietz, Michael on 4/4/11.
//  Copyright 2011 Michael Dietz
//


#import "APCConnection.h"

#define VERBOSE 1

@implementation APCConnection

@synthesize contentType;

#pragma mark Synchronous Call Get

-(id)init{
	if((self = [super init])){
		contentType = @"text/json";
	}
	return self;
}

#pragma mark Asyncronous Call Post

-(void)   callURLAsyncPost:(NSString*)url:(NSString*)postdata:(id<QNotifyBasicConnectionDelegate>)_delegate{
	
	delegate = _delegate;
	
#if VERBOSE >= 2
	NSLog(@"Request: %@", postdata);
#endif
	
	NSData*   requestData = [postdata dataUsingEncoding:NSUTF8StringEncoding];
	NSString* requestDataLengthString = [[NSString alloc] initWithFormat:@"%d", [requestData length]];
	
	NSMutableURLRequest *request = [[[NSMutableURLRequest alloc] init] autorelease];  
	[request setURL:[NSURL URLWithString:url]];  
	[request setHTTPMethod:@"POST"];  
	[request setValue:contentType forHTTPHeaderField:@"Content-Type"];
	[request setHTTPBody:requestData];
	[request setValue:requestDataLengthString forHTTPHeaderField:@"Content-Length"];
	[request setTimeoutInterval:30.0];
	
#if VERBOSE >= 1
	NSLog(@"Trying to load Async Post %@", url);
#endif
	
	NSURLConnection *connection=[[NSURLConnection alloc] initWithRequest:request delegate:self];
	if (connection) {
		receivedData=[[NSMutableData data] retain];
	} else {
		[delegate dataLoadingError:@"Error during connection init"];
	}
}


#pragma mark ConnectionDelegateMethods

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
	[receivedData appendData:data];
}

- (void)connection:(NSURLConnection *)connection
  didFailWithError:(NSError *)error
{
	
#if VERBOSE >= 1
	NSLog(@"Connection failed");
#endif
	
	NSString* errorText = [[NSString alloc] initWithFormat:@"Connection failed: %@", [error localizedDescription]];
	[delegate dataLoadingError:errorText];
	[connection release];
	[receivedData release];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
	
#if VERBOSE >= 2
	NSString* str = [[NSString alloc] initWithData:receivedData encoding:NSASCIIStringEncoding];
	NSLog(@"Connection successful %@", str);
#else if VERBOSE >= 1
	NSLog(@"Connection successful");
#endif
	
	[delegate dataLoadingSuccessful:receivedData:NO];
	
	[connection release];
}

@end
