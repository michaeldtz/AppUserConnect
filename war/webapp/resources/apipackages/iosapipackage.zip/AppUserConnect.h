//
//  AppUserConnect
//
//  Created by Dietz, Michael on 4/4/11.
//  Copyright 2011 Michael Dietz
//


#import <Foundation/Foundation.h>
#import "APCConnection.h"

@protocol APCActionHandler

-(void)handleAction:(NSString*)action:(NSString*)actionName:(NSArray*)actionPieces;

@end


@interface AppUserConnect : NSObject <QNotifyBasicConnectionDelegate, UIAlertViewDelegate> {

	NSString* button1Acti;
	NSString* button2Acti;
	NSString* button3Acti;
	
}

+(void)executeAppUserConnect:(NSString*)qnid;
+(void)executeAppUserConnect:(NSString*)qnid withPosition:(NSString*)position;
+(void)executeAppUserConnectOnPosition:(NSString*)position;

+(NSString *)generateUUID;

@end
